import Link from "next/link";
import { fmt, getArticles } from "@/lib/api";

export default async function Home() {
  const articles = await getArticles();
  return (
    <main>
      <h1>Code you can run, written about what shipped this week.</h1>
      <p className="muted" style={{ marginBottom: 40 }}>Every code sample is executed before it is published.</p>
      {articles.length === 0 && <p className="muted">No articles yet. The first one appears after it passes review.</p>}
      {articles.map((a) => (
        <Link key={a.slug} href={`/blog/${a.slug}`} className="post-row">
          <h2>{a.title}</h2>
          <p className="muted" style={{ margin: "0 0 6px" }}>{a.meta_description}</p>
          <span className="tags">{fmt(a.published_at)}{a.tech_tags.length ? ` · ${a.tech_tags.join(", ")}` : ""}</span>
        </Link>
      ))}
    </main>
  );
}
