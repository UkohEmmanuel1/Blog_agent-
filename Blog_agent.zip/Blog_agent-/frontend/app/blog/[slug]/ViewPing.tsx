"use client";
import { useEffect } from "react";
import { API } from "@/lib/api";

export default function ViewPing({ slug }: { slug: string }) {
  useEffect(() => {
    fetch(`${API}/api/articles/${slug}/view/`, { method: "POST" }).catch(() => {});
  }, [slug]);
  return null;
}
