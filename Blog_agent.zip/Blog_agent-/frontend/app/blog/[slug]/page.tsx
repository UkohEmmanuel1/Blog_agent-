import { notFound } from "next/navigation";
import type { Metadata } from "next";
import ReactMarkdown from "react-markdown";
import { fmt, getArticle } from "@/lib/api";
import ViewPing from "./ViewPing";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const a = await getArticle(params.slug);
  return a ? { title: a.title, description: a.meta_description, keywords: a.keywords } : {};
}

export default async function Post({ params }: Props) {
  const a = await getArticle(params.slug);
  if (!a) notFound();
  return (
    <article>
      <ViewPing slug={a.slug} />
      <p className="muted">{fmt(a.published_at)}{a.tech_tags.length ? ` · ${a.tech_tags.join(", ")}` : ""}</p>
      <div className="prose"><ReactMarkdown>{a.body_md ?? ""}</ReactMarkdown></div>
    </article>
  );
}
