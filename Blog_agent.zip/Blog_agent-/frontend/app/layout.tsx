import type { Metadata } from "next";
import { Instrument_Sans, Source_Serif_4 } from "next/font/google";
import Link from "next/link";
import "./globals.css";

const ui = Instrument_Sans({ subsets: ["latin"], variable: "--font-ui" });
const body = Source_Serif_4({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = { title: "Atlas Dev Blog", description: "Practical, tested tech writing." };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${ui.variable} ${body.variable}`}>
      <body>
        <div className="wrap" id="top">
          <header className="site">
            <Link className="brand" href="/">Atlas Dev Blog</Link>
            <Link href="/admin" className="muted">Control centre</Link>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
