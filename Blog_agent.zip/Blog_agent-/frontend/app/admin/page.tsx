"use client";
import { useCallback, useEffect, useState } from "react";
import { API } from "@/lib/api";

type Overview = {
  state: { paused: boolean; auto_publish: boolean; daily_publish_cap: number; daily_post_cap: number };
  story_counts: Record<string, number>;
  pending: { id: number; article: { title: string; body_md: string }; code_ok: boolean; snippets: number }[];
  runs: { id: number; agent: string; status: string; message: string; started_at: string }[];
};

export default function Admin() {
  const [key, setKey] = useState("");
  const [data, setData] = useState<Overview | null>(null);
  const [err, setErr] = useState("");
  const [notes, setNotes] = useState<Record<number, string>>({});

  const call = useCallback(async (path: string, body?: object) => {
    const r = await fetch(`${API}/api/admin/${path}`, {
      method: body ? "POST" : "GET",
      headers: { "X-Admin-Key": key, "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) throw new Error(r.status === 403 ? "Wrong admin key." : `Request failed (${r.status}).`);
    return r.json();
  }, [key]);

  const load = useCallback(async () => {
    if (!key) return;
    try { setData(await call("overview/")); setErr(""); } catch (e) { setErr((e as Error).message); }
  }, [call, key]);

  useEffect(() => { setKey(sessionStorage.getItem("atlas_key") ?? ""); }, []);
  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, [load]);

  const act = async (path: string, body: object) => { try { await call(path, body); await load(); } catch (e) { setErr((e as Error).message); } };

  if (!data) {
    return (
      <main className="wide">
        <h1>Control centre</h1>
        <div className="panel">
          <label htmlFor="k">Admin key</label>
          <div className="row" style={{ marginTop: 8 }}>
            <input id="k" type="password" value={key} onChange={(e) => setKey(e.target.value)} />
            <button onClick={() => { sessionStorage.setItem("atlas_key", key); load(); }}>Unlock</button>
          </div>
          {err && <p className="error">{err}</p>}
        </div>
      </main>
    );
  }

  const s = data.state;
  return (
    <main className="wide">
      <h1>Control centre</h1>
      {err && <p className="error">{err}</p>}
      <div className="panel">
        <h3>System</h3>
        <div className="row">
          <button className={s.paused ? "" : "danger"} onClick={() => act("state/", { paused: !s.paused })}>
            {s.paused ? "Resume pipeline" : "Pause pipeline"}
          </button>
          <button className="ghost" onClick={() => act("state/", { auto_publish: !s.auto_publish })}>
            Auto-publish: {s.auto_publish ? "on" : "off"}
          </button>
          <button className="ghost" onClick={() => act("run/", {})}>Run a cycle now</button>
          <span className="muted">Limits: {s.daily_publish_cap} articles and {s.daily_post_cap} social posts per day</span>
        </div>
        <p className="muted" style={{ marginBottom: 0 }}>
          Stories: {Object.entries(data.story_counts).map(([k, v]) => `${k} ${v}`).join(", ") || "none yet"}
        </p>
      </div>

      <div className="panel">
        <h3>Waiting for your review ({data.pending.length})</h3>
        {data.pending.length === 0 && <p className="muted">Nothing to review.</p>}
        {data.pending.map((p) => (
          <div key={p.id} style={{ borderTop: "1px solid var(--line)", padding: "12px 0" }}>
            <strong>{p.article.title}</strong>{" "}
            <span className={`pill ${p.code_ok ? "ok" : "error"}`}>
              {p.snippets} code blocks, {p.code_ok ? "none failing" : "some failing"}
            </span>
            <details style={{ margin: "8px 0" }}>
              <summary>Read draft</summary>
              <pre style={{ whiteSpace: "pre-wrap" }}>{p.article.body_md}</pre>
            </details>
            <textarea rows={2} placeholder="Notes for the writer (used if you reject)" value={notes[p.id] ?? ""}
              onChange={(e) => setNotes({ ...notes, [p.id]: e.target.value })} />
            <div className="row" style={{ marginTop: 8 }}>
              <button onClick={() => act(`approvals/${p.id}/decide/`, { decision: "approved" })}>Approve and publish</button>
              <button className="ghost" onClick={() => act(`approvals/${p.id}/decide/`, { decision: "rejected", notes: notes[p.id] })}>
                Reject and rewrite
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="panel">
        <h3>Recent agent activity</h3>
        <table>
          <tbody>
            {data.runs.map((r) => (
              <tr key={r.id}>
                <td>{r.agent}</td>
                <td className={r.status === "ok" ? "ok" : r.status === "error" ? "error" : "warn"}>{r.status}</td>
                <td className="muted">{r.message}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
