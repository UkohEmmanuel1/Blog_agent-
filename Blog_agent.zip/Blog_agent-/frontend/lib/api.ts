export const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type Article = {
  title: string; slug: string; meta_description: string; tech_tags: string[];
  published_at: string | null; updated_at: string; body_md?: string; keywords?: string[];
};

export async function getArticles(): Promise<Article[]> {
  try {
    const r = await fetch(`${API}/api/articles/`, { next: { revalidate: 60 } });
    return r.ok ? r.json() : [];
  } catch {
    return [];
  }
}

export async function getArticle(slug: string): Promise<Article | null> {
  try {
    const r = await fetch(`${API}/api/articles/${slug}/`, { next: { revalidate: 60 } });
    return r.ok ? r.json() : null;
  } catch {
    return null;
  }
}

export const fmt = (d: string | null) =>
  d ? new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "";
