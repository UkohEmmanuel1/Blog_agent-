# Atlas Blog Agent

A multi-agent system that runs a tech blog around the clock: it finds stories, fact-checks them,
writes articles, executes every code sample, waits for human approval, publishes to the site and
posts to social channels. Django + Celery backend, Next.js frontend.

```
Scheduler (Celery beat, every 15 min)
  -> Orchestrator (state machine, caps, pause switch)
     research -> verification -> editorial + SEO + media -> engineering (run code)
        -> approval gate -> publish -> distribution -> analytics
Daily: freshness check re-runs code in live articles; broken ones go back to editorial.
```

## Run it

```bash
cp .env.example .env       # set ADMIN_API_KEY and LLM_API_KEY at minimum
docker compose up --build
docker compose exec api python manage.py createsuperuser   # optional, for /admin
```

Site: http://localhost:3000 · Control centre: http://localhost:3000/admin · API: http://localhost:8000/api

Without Docker: `cd backend && pip install -r requirements.txt && python manage.py migrate`, run
`celery -A config worker -l info` and `celery -A config beat -l info` (needs Redis), then
`cd frontend && npm install && npm run dev`.

## Safety controls

- Approval gate is on by default. Turn on auto-publish from the control centre only when you trust the output.
- Pause switch, daily publish cap, daily social post cap and daily agent-run cap (`SystemState`).
- An article cannot reach review unless its Python samples ran cleanly. After 3 failed attempts the story is dropped.
- Every agent run and orchestrator decision is stored in `AgentRun` and `AuditLog`.

## Status and known gaps

- Orchestrator state machine is covered by a mocked end-to-end run only. No automated tests yet.
- `SANDBOX=subprocess` is not a security boundary. Use `SANDBOX=docker` (needs Docker socket access) in production.
- Only Python snippets are executed. Other languages are stored as untested.
- dev.to, X and LinkedIn posters are implemented against their public APIs but untested against live accounts.
  X's API is paid and LinkedIn needs app approval. Reddit is deliberately not automated.
- Media agent is a placeholder. Analytics agent only summarises page views.
