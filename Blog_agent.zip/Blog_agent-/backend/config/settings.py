import os
from datetime import timedelta
from pathlib import Path
from celery.schedules import crontab

BASE_DIR = Path(__file__).resolve().parent.parent
env = os.environ.get

SECRET_KEY = env("DJANGO_SECRET_KEY", "dev-insecure-key")
DEBUG = env("DJANGO_DEBUG", "0") == "1"
ALLOWED_HOSTS = env("ALLOWED_HOSTS", "*").split(",")

INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth", "django.contrib.contenttypes",
    "django.contrib.sessions", "django.contrib.messages", "django.contrib.staticfiles",
    "rest_framework", "corsheaders", "core",
]
MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]
ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates", "DIRS": [], "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages"]},
}]

if env("POSTGRES_DB"):
    DATABASES = {"default": {
        "ENGINE": "django.db.backends.postgresql", "NAME": env("POSTGRES_DB"),
        "USER": env("POSTGRES_USER", "atlas"), "PASSWORD": env("POSTGRES_PASSWORD", ""),
        "HOST": env("POSTGRES_HOST", "localhost"), "PORT": env("POSTGRES_PORT", "5432")}}
else:
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
USE_TZ = True
TIME_ZONE = "UTC"
CORS_ALLOWED_ORIGINS = [env("FRONTEND_ORIGIN", "http://localhost:3000")]
CORS_ALLOW_HEADERS = ["content-type", "x-admin-key"]
REST_FRAMEWORK = {"DEFAULT_AUTHENTICATION_CLASSES": [], "DEFAULT_PERMISSION_CLASSES": []}

ADMIN_API_KEY = env("ADMIN_API_KEY", "")
SITE_URL = env("SITE_URL", "http://localhost:3000")
SANDBOX = env("SANDBOX", "subprocess")
LLM_API_KEY = env("LLM_API_KEY", "")
LLM_BASE_URL = env("LLM_BASE_URL", "https://api.groq.com/openai/v1")
LLM_MODEL = env("LLM_MODEL", "llama-3.3-70b-versatile")
DEVTO_API_KEY = env("DEVTO_API_KEY", "")
X_ACCESS_TOKEN = env("X_ACCESS_TOKEN", "")
LINKEDIN_ACCESS_TOKEN = env("LINKEDIN_ACCESS_TOKEN", "")
LINKEDIN_AUTHOR_URN = env("LINKEDIN_AUTHOR_URN", "")

CELERY_BROKER_URL = env("REDIS_URL", "redis://localhost:6379/0")
CELERY_RESULT_BACKEND = CELERY_BROKER_URL
CELERY_TIMEZONE = "UTC"
CELERY_BEAT_SCHEDULE = {
    "orchestrator-tick": {"task": "core.tasks.tick",
        "schedule": timedelta(minutes=int(env("TICK_MINUTES", "15")))},
    "freshness-daily": {"task": "core.tasks.freshness_check", "schedule": crontab(hour=3, minute=0)},
    "analytics-hourly": {"task": "core.tasks.analytics", "schedule": crontab(minute=5)},
}
