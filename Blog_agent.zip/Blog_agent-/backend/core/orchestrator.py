"""Central orchestrator: a state machine that moves one batch of work per stage on every tick.

Stages run last-to-first so an item advances at most one stage per tick.
Story:   new -> verified -> drafted -> published -> distributed   (or rejected / failed)
Article: draft -> tested -> pending_review -> approved -> published (needs_update -> draft on stale code)
"""
from django.utils import timezone
from .agents.analytics import AnalyticsAgent
from .agents.distribution import DistributionAgent
from .agents.editorial import EditorialAgent
from .agents.engineering import EngineeringAgent
from .agents.media import MediaAgent
from .agents.research import ResearchAgent
from .agents.seo import SEOAgent
from .agents.verification import VerificationAgent
from .models import Approval, Article, AgentRun, AuditLog, SocialPost, Story, SystemState

MAX_ATTEMPTS = 3
BATCH = 2


def _log(action, detail=""):
    AuditLog.objects.create(actor="orchestrator", action=action, detail=detail)


def tick():
    state = SystemState.get()
    if state.paused:
        _log("skipped", "system paused")
        return "paused"
    today = timezone.localdate()
    if AgentRun.objects.filter(started_at__date=today).count() >= state.daily_run_cap:
        _log("skipped", "daily run cap reached")
        return "cap"
    distribute(state, today)
    publish(state, today)
    review_gate(state)
    test_code()
    write()
    revise_stale()
    verify()
    research()
    return "ok"


def distribute(state, today):
    posted = SocialPost.objects.filter(posted_at__date=today).count()
    if posted >= state.daily_post_cap:
        return
    for story in Story.objects.filter(status=Story.Status.PUBLISHED)[:BATCH]:
        article = story.articles.filter(is_live=True).first()
        if article:
            DistributionAgent().execute(story=story, article=article)
        story.status = Story.Status.DISTRIBUTED
        story.save()


def publish(state, today):
    done = Article.objects.filter(published_at__date=today).count()
    for a in Article.objects.filter(status=Article.Status.APPROVED):
        first_time = a.published_at is None
        if first_time and done >= state.daily_publish_cap:
            continue
        a.status, a.is_live = Article.Status.PUBLISHED, True
        a.published_at = a.published_at or timezone.now()
        a.save()
        if first_time:
            done += 1
            a.story.status = Story.Status.PUBLISHED
            a.story.save()
        _log("published", a.slug)


def review_gate(state):
    for a in Article.objects.filter(status=Article.Status.TESTED):
        if state.auto_publish:
            Approval.objects.create(article=a, decision="approved", auto=True, decided_at=timezone.now())
            a.status = Article.Status.APPROVED
        else:
            Approval.objects.create(article=a)
            a.status = Article.Status.PENDING_REVIEW
        a.save()


def test_code():
    for a in Article.objects.filter(status=Article.Status.DRAFT)[:BATCH]:
        run = EngineeringAgent().execute(article=a, story=a.story)
        a.refresh_from_db()
        if run.message == "passed":
            a.status = Article.Status.TESTED
            a.save()
            continue
        story = a.story
        story.attempts += 1
        story.status = Story.Status.FAILED if story.attempts >= MAX_ATTEMPTS else Story.Status.VERIFIED
        story.save()


def write():
    for story in Story.objects.filter(status=Story.Status.VERIFIED)[:BATCH]:
        run = EditorialAgent().execute(story=story)
        if run.status != "ok":
            continue
        article = story.articles.first()
        SEOAgent().execute(article=article, story=story)
        MediaAgent().execute(article=article, story=story)


def revise_stale():
    for a in Article.objects.filter(status=Article.Status.NEEDS_UPDATE)[:BATCH]:
        EditorialAgent().execute(article=a, story=a.story)


def verify():
    for story in Story.objects.filter(status=Story.Status.NEW)[:BATCH]:
        VerificationAgent().execute(story=story)


def research():
    backlog = Story.objects.filter(status__in=[Story.Status.NEW, Story.Status.VERIFIED]).count()
    if backlog < 3:
        ResearchAgent().execute()


def freshness_check():
    """Daily: re-run code in live articles. Broken samples flag the article for revision."""
    n = 0
    for a in Article.objects.filter(is_live=True, status=Article.Status.PUBLISHED):
        run = EngineeringAgent().execute(article=a, story=a.story)
        if run.message != "passed":
            a.status = Article.Status.NEEDS_UPDATE
            a.save()
            n += 1
    _log("freshness_check", f"{n} articles flagged")
    return n


def analytics():
    AnalyticsAgent().execute()
