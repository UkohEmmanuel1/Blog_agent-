from django.contrib.auth import get_user_model
from django.db import models
from django.utils import timezone


class NewsSource(models.Model):
    name = models.CharField(max_length=120)
    url = models.URLField()
    kind = models.CharField(max_length=30, default="rss")
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Story(models.Model):
    class Status(models.TextChoices):
        NEW = "new"
        VERIFIED = "verified"
        DRAFTED = "drafted"
        PUBLISHED = "published"
        DISTRIBUTED = "distributed"
        REJECTED = "rejected"
        FAILED = "failed"

    source = models.ForeignKey(NewsSource, null=True, blank=True, on_delete=models.SET_NULL)
    title = models.CharField(max_length=300)
    url = models.URLField(unique=True)
    summary = models.TextField(blank=True)
    source_type = models.CharField(max_length=30, default="news")
    tech_tags = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NEW)
    attempts = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class StoryClaim(models.Model):
    story = models.ForeignKey(Story, related_name="claims", on_delete=models.CASCADE)
    text = models.TextField()
    verdict = models.CharField(max_length=20, default="unverified")
    evidence = models.TextField(blank=True)


class Article(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft"
        TESTED = "tested"
        PENDING_REVIEW = "pending_review"
        APPROVED = "approved"
        PUBLISHED = "published"
        NEEDS_UPDATE = "needs_update"

    story = models.ForeignKey(Story, related_name="articles", on_delete=models.CASCADE)
    title = models.CharField(max_length=300)
    slug = models.SlugField(max_length=320, unique=True)
    body_md = models.TextField()
    meta_description = models.CharField(max_length=320, blank=True)
    keywords = models.JSONField(default=list, blank=True)
    tech_tags = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    is_live = models.BooleanField(default=False)
    feedback = models.TextField(blank=True)
    published_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class ArticleRevision(models.Model):
    article = models.ForeignKey(Article, related_name="revisions", on_delete=models.CASCADE)
    body_md = models.TextField()
    reason = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class CodeSnippet(models.Model):
    article = models.ForeignKey(Article, related_name="snippets", on_delete=models.CASCADE)
    language = models.CharField(max_length=30, blank=True)
    code = models.TextField()
    tested = models.BooleanField(null=True, blank=True)  # None = not run
    last_output = models.TextField(blank=True)
    tested_at = models.DateTimeField(null=True, blank=True)


class Approval(models.Model):
    class Decision(models.TextChoices):
        PENDING = "pending"
        APPROVED = "approved"
        REJECTED = "rejected"

    article = models.ForeignKey(Article, related_name="approvals", on_delete=models.CASCADE)
    reviewer = models.ForeignKey(get_user_model(), null=True, blank=True, on_delete=models.SET_NULL)
    decision = models.CharField(max_length=20, choices=Decision.choices, default=Decision.PENDING)
    auto = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)


class MediaAsset(models.Model):
    article = models.ForeignKey(Article, related_name="media", on_delete=models.CASCADE)
    kind = models.CharField(max_length=20, default="image")
    url = models.URLField()
    alt = models.CharField(max_length=300, blank=True)


class SocialAccount(models.Model):
    platform = models.CharField(max_length=20)  # devto | x | linkedin
    handle = models.CharField(max_length=120, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.platform}:{self.handle}"


class SocialPost(models.Model):
    account = models.ForeignKey(SocialAccount, related_name="posts", on_delete=models.CASCADE)
    article = models.ForeignKey(Article, related_name="social_posts", on_delete=models.CASCADE)
    text = models.TextField()
    status = models.CharField(max_length=20, default="pending")  # pending | posted | failed
    external_id = models.CharField(max_length=200, blank=True)
    error = models.TextField(blank=True)
    posted_at = models.DateTimeField(null=True, blank=True)


class AgentRun(models.Model):
    agent = models.CharField(max_length=40)
    status = models.CharField(max_length=20, default="running")  # running | ok | error
    story = models.ForeignKey(Story, null=True, blank=True, on_delete=models.SET_NULL)
    article = models.ForeignKey(Article, null=True, blank=True, on_delete=models.SET_NULL)
    message = models.TextField(blank=True)
    started_at = models.DateTimeField(default=timezone.now)
    finished_at = models.DateTimeField(null=True, blank=True)


class AuditLog(models.Model):
    run = models.ForeignKey(AgentRun, null=True, blank=True, on_delete=models.SET_NULL)
    actor = models.CharField(max_length=60)
    action = models.CharField(max_length=120)
    detail = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class ArticleMetric(models.Model):
    article = models.ForeignKey(Article, related_name="metrics", on_delete=models.CASCADE)
    date = models.DateField(default=timezone.localdate)
    views = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ("article", "date")


class SystemState(models.Model):
    """Singleton: operating state and emergency controls."""
    paused = models.BooleanField(default=False)
    auto_publish = models.BooleanField(default=False)
    daily_publish_cap = models.PositiveSmallIntegerField(default=3)
    daily_post_cap = models.PositiveSmallIntegerField(default=6)
    daily_run_cap = models.PositiveSmallIntegerField(default=200)

    @classmethod
    def get(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj
