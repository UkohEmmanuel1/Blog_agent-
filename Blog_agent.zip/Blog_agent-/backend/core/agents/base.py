from django.utils import timezone
from core.models import AgentRun, AuditLog


class BaseAgent:
    """Every agent execution is recorded as an AgentRun plus audit entries."""
    name = "base"

    def execute(self, story=None, article=None, **kw):
        run = AgentRun.objects.create(agent=self.name, story=story, article=article)
        try:
            msg = self.run(story=story, article=article, **kw) or ""
            run.status, run.message = "ok", str(msg)[:2000]
        except Exception as e:  # noqa: BLE001 - agents must never crash the orchestrator
            run.status, run.message = "error", f"{type(e).__name__}: {e}"[:2000]
        run.finished_at = timezone.now()
        run.save()
        AuditLog.objects.create(run=run, actor=self.name, action=f"run:{run.status}", detail=run.message)
        return run

    def run(self, story=None, article=None, **kw):
        raise NotImplementedError
