import re
import subprocess
import sys
from django.conf import settings
from django.utils import timezone
from core.models import Article, CodeSnippet
from .base import BaseAgent

FENCE = re.compile(r"```(\w+)?\n(.*?)```", re.S)


def run_python(code: str, timeout: int = 15):
    if settings.SANDBOX == "docker":
        cmd = ["docker", "run", "--rm", "-i", "--network", "none", "-m", "256m", "--cpus", "0.5",
               "python:3.12-slim", "python", "-I", "-"]
    else:  # NOT a security boundary. Use SANDBOX=docker in production.
        cmd = [sys.executable, "-I", "-"]
    try:
        p = subprocess.run(cmd, input=code, capture_output=True, text=True, timeout=timeout)
        return p.returncode == 0, (p.stdout + p.stderr)[-2000:]
    except subprocess.TimeoutExpired:
        return False, "timeout"


class EngineeringAgent(BaseAgent):
    """Extracts code blocks and runs the Python ones. Failures go back to the editor."""
    name = "engineering"

    def run(self, article: Article = None, **kw):
        article.snippets.all().delete()
        failures = []
        for lang, code in FENCE.findall(article.body_md):
            snip = CodeSnippet.objects.create(article=article, language=lang or "", code=code)
            if lang.lower() in ("python", "py"):
                ok, out = run_python(code)
                snip.tested, snip.last_output, snip.tested_at = ok, out, timezone.now()
                snip.save()
                if not ok:
                    failures.append(out)
        if failures:
            article.feedback = "Code failed when executed:\n" + "\n---\n".join(failures)
            article.save()
            return "failed"
        return "passed"
