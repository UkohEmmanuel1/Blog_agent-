from datetime import date, timedelta
import requests
from core.models import Story
from .base import BaseAgent

HN = "https://hacker-news.firebaseio.com/v0"


class ResearchAgent(BaseAgent):
    """Discovers tech stories from Hacker News and GitHub."""
    name = "research"

    def run(self, **kw):
        created = 0
        ids = requests.get(f"{HN}/topstories.json", timeout=15).json()[:30]
        for i in ids:
            it = requests.get(f"{HN}/item/{i}.json", timeout=15).json() or {}
            if it.get("score", 0) < 150 or not it.get("url"):
                continue
            _, new = Story.objects.get_or_create(
                url=it["url"], defaults={"title": it["title"][:300], "source_type": "hackernews"})
            created += new
        since = (date.today() - timedelta(days=7)).isoformat()
        r = requests.get("https://api.github.com/search/repositories", timeout=15,
                         params={"q": f"created:>{since}", "sort": "stars", "order": "desc", "per_page": 5})
        for repo in r.json().get("items", []):
            _, new = Story.objects.get_or_create(
                url=repo["html_url"],
                defaults={"title": repo["full_name"], "summary": repo.get("description") or "",
                          "source_type": "github", "tech_tags": [repo.get("language") or ""]})
            created += new
        return f"{created} new stories"
