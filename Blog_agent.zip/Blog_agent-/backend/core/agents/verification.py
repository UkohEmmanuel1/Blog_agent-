import re
import requests
from core import llm
from core.models import Story, StoryClaim
from .base import BaseAgent


def fetch_text(url: str, limit: int = 8000) -> str:
    html = requests.get(url, timeout=20, headers={"User-Agent": "AtlasBot/1.0"}).text
    html = re.sub(r"(?s)<(script|style).*?</\1>", " ", html)
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))[:limit]


class VerificationAgent(BaseAgent):
    """Extracts claims from the primary source and judges whether the story is safe to cover."""
    name = "verification"

    def run(self, story: Story = None, **kw):
        text = fetch_text(story.url)
        out = llm.chat_json(
            "You fact-check tech news against the supplied source text only. Return "
            '{"summary": str, "tech_tags": [str], "publishable": bool, '
            '"claims": [{"text": str, "verdict": "supported|unsupported|unverifiable", "evidence": str}]}. '
            "publishable is false if key claims are unsupported or the source is thin.",
            f"Title: {story.title}\nURL: {story.url}\nSource text:\n{text}")
        for c in out.get("claims", []):
            StoryClaim.objects.create(story=story, text=c["text"], verdict=c.get("verdict", "unverifiable"),
                                      evidence=c.get("evidence", ""))
        story.summary = out.get("summary", story.summary)
        story.tech_tags = out.get("tech_tags", story.tech_tags)
        story.status = Story.Status.VERIFIED if out.get("publishable") else Story.Status.REJECTED
        story.save()
        return story.status
