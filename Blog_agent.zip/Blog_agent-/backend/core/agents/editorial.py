from django.utils.text import slugify
from core import llm
from core.models import Article, ArticleRevision, Story
from .base import BaseAgent

SYSTEM = ("You write accurate, practical tech blog posts for developers: tutorials, explainers and "
          "release breakdowns. Use only the verified claims given. Every code sample must be complete, "
          "runnable and fenced with a language tag. Never invent APIs. Return JSON "
          '{"title": str, "body_md": str, "tech_tags": [str]}.')


class EditorialAgent(BaseAgent):
    """Writes a new article for a verified story, or rewrites it using feedback."""
    name = "editorial"

    def run(self, story: Story = None, article: Article = None, **kw):
        article = article or story.articles.first()
        story = story or article.story
        claims = "\n".join(f"- {c.text} ({c.verdict})" for c in story.claims.filter(verdict="supported"))
        prompt = f"Story: {story.title}\nURL: {story.url}\nSummary: {story.summary}\nVerified claims:\n{claims}"
        if article:
            prompt += f"\n\nCurrent draft:\n{article.body_md}\n\nFix this feedback:\n{article.feedback}"
        out = llm.chat_json(SYSTEM, prompt)
        if article:
            ArticleRevision.objects.create(article=article, body_md=article.body_md, reason=article.feedback[:300])
            article.body_md, article.title = out["body_md"], out.get("title", article.title)
            article.feedback, article.status = "", Article.Status.DRAFT
            article.save()
        else:
            slug, n = slugify(out["title"])[:300], 1
            while Article.objects.filter(slug=slug).exists():
                n += 1
                slug = f"{slugify(out['title'])[:290]}-{n}"
            article = Article.objects.create(story=story, title=out["title"], slug=slug, body_md=out["body_md"],
                                             tech_tags=out.get("tech_tags", story.tech_tags))
        story.status = Story.Status.DRAFTED
        story.save()
        article.snippets.all().delete()
        return article.slug
