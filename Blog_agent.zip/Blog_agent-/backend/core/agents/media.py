from .base import BaseAgent


class MediaAgent(BaseAgent):
    """Placeholder: plug in an image/video generator and create MediaAsset rows."""
    name = "media"

    def run(self, **kw):
        return "skipped: no media provider configured"
