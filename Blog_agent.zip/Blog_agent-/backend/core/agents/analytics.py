from django.db.models import Sum
from core.models import Article, AuditLog
from .base import BaseAgent


class AnalyticsAgent(BaseAgent):
    """Summarises performance so humans (and later the research step) can see what works."""
    name = "analytics"

    def run(self, **kw):
        top = (Article.objects.filter(is_live=True).annotate(v=Sum("metrics__views"))
               .order_by("-v")[:5])
        summary = ", ".join(f"{a.slug}: {a.v or 0}" for a in top) or "no live articles"
        AuditLog.objects.create(actor="analytics", action="top_articles", detail=summary)
        return summary
