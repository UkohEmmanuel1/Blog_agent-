import requests
from django.conf import settings
from django.utils import timezone
from core import llm
from core.models import Article, SocialAccount, SocialPost
from .base import BaseAgent


def post_devto(article, url, text):
    r = requests.post("https://dev.to/api/articles", timeout=20,
        headers={"api-key": settings.DEVTO_API_KEY},
        json={"article": {"title": article.title, "published": True, "canonical_url": url,
                          "body_markdown": article.body_md, "tags": [t.lower()[:20] for t in article.tech_tags[:4]]}})
    r.raise_for_status()
    return str(r.json().get("id", ""))


def post_x(article, url, text):
    r = requests.post("https://api.twitter.com/2/tweets", timeout=20,
        headers={"Authorization": f"Bearer {settings.X_ACCESS_TOKEN}"}, json={"text": text[:280]})
    r.raise_for_status()
    return r.json()["data"]["id"]


def post_linkedin(article, url, text):
    r = requests.post("https://api.linkedin.com/v2/ugcPosts", timeout=20,
        headers={"Authorization": f"Bearer {settings.LINKEDIN_ACCESS_TOKEN}", "X-Restli-Protocol-Version": "2.0.0"},
        json={"author": settings.LINKEDIN_AUTHOR_URN, "lifecycleState": "PUBLISHED",
              "specificContent": {"com.linkedin.ugc.ShareContent": {
                  "shareCommentary": {"text": text}, "shareMediaCategory": "NONE"}},
              "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}})
    r.raise_for_status()
    return r.headers.get("x-restli-id", "")


POSTERS = {
    "devto": (post_devto, lambda: settings.DEVTO_API_KEY),
    "x": (post_x, lambda: settings.X_ACCESS_TOKEN),
    "linkedin": (post_linkedin, lambda: settings.LINKEDIN_ACCESS_TOKEN and settings.LINKEDIN_AUTHOR_URN),
}


class DistributionAgent(BaseAgent):
    """Writes a platform-specific post and publishes it to each configured account."""
    name = "distribution"

    def run(self, article: Article = None, **kw):
        url = f"{settings.SITE_URL}/blog/{article.slug}"
        done = 0
        for platform, (poster, configured) in POSTERS.items():
            if not configured():
                continue
            account, _ = SocialAccount.objects.get_or_create(platform=platform)
            if not account.active:
                continue
            text = llm.chat(f"Write a short {platform} post promoting this developer article. "
                            "Plain text, no hashtag spam, include the link.",
                            f"{article.title}\n{article.meta_description}\n{url}")
            sp = SocialPost.objects.create(account=account, article=article, text=text)
            try:
                sp.external_id = poster(article, url, text)
                sp.status, sp.posted_at = "posted", timezone.now()
                done += 1
            except Exception as e:  # noqa: BLE001
                sp.status, sp.error = "failed", str(e)[:500]
            sp.save()
        return f"{done} posts"
