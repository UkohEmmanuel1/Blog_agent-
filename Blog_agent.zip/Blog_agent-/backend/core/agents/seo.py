from core import llm
from core.models import Article
from .base import BaseAgent


class SEOAgent(BaseAgent):
    """Adds developer-intent keywords and a meta description."""
    name = "seo"

    def run(self, article: Article = None, **kw):
        out = llm.chat_json(
            'Return {"meta_description": str (<=155 chars), "keywords": [str]} targeting developer search '
            'intent ("how to", "X vs Y", error messages). Do not change claims.',
            f"{article.title}\n\n{article.body_md[:4000]}")
        article.meta_description = out.get("meta_description", "")[:320]
        article.keywords = out.get("keywords", [])
        article.save()
        return "seo ok"
