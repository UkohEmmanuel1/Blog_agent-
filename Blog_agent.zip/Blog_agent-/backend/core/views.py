from django.db.models import Count, F
from django.utils import timezone
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from .auth import AdminKey
from .models import Approval, Article, ArticleMetric, AgentRun, Story, SystemState
from .tasks import tick


def article_dict(a, full=False):
    d = {"title": a.title, "slug": a.slug, "meta_description": a.meta_description,
         "tech_tags": a.tech_tags, "published_at": a.published_at, "updated_at": a.updated_at}
    if full:
        d["body_md"] = a.body_md
        d["keywords"] = a.keywords
    return d


@api_view(["GET"])
def health(request):
    return Response({"ok": True})


@api_view(["GET"])
def articles(request):
    qs = Article.objects.filter(is_live=True).order_by("-published_at")[:50]
    return Response([article_dict(a) for a in qs])


@api_view(["GET"])
def article_detail(request, slug):
    a = Article.objects.filter(slug=slug, is_live=True).first()
    return Response(article_dict(a, True)) if a else Response({"detail": "Not found"}, status=404)


@api_view(["POST"])
def article_view(request, slug):
    a = Article.objects.filter(slug=slug, is_live=True).first()
    if not a:
        return Response(status=404)
    m, _ = ArticleMetric.objects.get_or_create(article=a, date=timezone.localdate())
    ArticleMetric.objects.filter(pk=m.pk).update(views=F("views") + 1)
    return Response({"ok": True})


def state_dict(s):
    return {k: getattr(s, k) for k in
            ("paused", "auto_publish", "daily_publish_cap", "daily_post_cap", "daily_run_cap")}


@api_view(["GET"])
@permission_classes([AdminKey])
def overview(request):
    pending = Approval.objects.filter(decision="pending").select_related("article")
    return Response({
        "state": state_dict(SystemState.get()),
        "story_counts": {r["status"]: r["n"] for r in Story.objects.values("status").annotate(n=Count("id"))},
        "pending": [{"id": p.id, "article": article_dict(p.article, True),
                     "code_ok": not p.article.snippets.filter(tested=False).exists(),
                     "snippets": p.article.snippets.count()} for p in pending],
        "runs": [{"id": r.id, "agent": r.agent, "status": r.status, "message": r.message[:200],
                  "started_at": r.started_at} for r in AgentRun.objects.order_by("-id")[:25]],
    })


@api_view(["POST"])
@permission_classes([AdminKey])
def set_state(request):
    s = SystemState.get()
    for k in ("paused", "auto_publish", "daily_publish_cap", "daily_post_cap", "daily_run_cap"):
        if k in request.data:
            setattr(s, k, request.data[k])
    s.save()
    return Response(state_dict(s))


@api_view(["POST"])
@permission_classes([AdminKey])
def decide(request, pk):
    ap = Approval.objects.filter(pk=pk, decision="pending").select_related("article__story").first()
    if not ap:
        return Response({"detail": "Not found"}, status=404)
    decision, notes = request.data.get("decision"), request.data.get("notes", "")
    if decision not in ("approved", "rejected"):
        return Response({"detail": "decision must be approved or rejected"}, status=400)
    ap.decision, ap.notes, ap.decided_at = decision, notes, timezone.now()
    ap.save()
    a = ap.article
    if decision == "approved":
        a.status = Article.Status.APPROVED
    else:  # send back to the editorial agent with the reviewer's notes
        a.feedback = notes or "Rejected by reviewer."
        a.status = Article.Status.DRAFT
        a.story.status = Story.Status.VERIFIED
        a.story.save()
    a.save()
    return Response({"ok": True})


@api_view(["POST"])
@permission_classes([AdminKey])
def run_now(request):
    tick.delay()
    return Response({"queued": True})
