from django.urls import path
from . import views

urlpatterns = [
    path("health/", views.health),
    path("articles/", views.articles),
    path("articles/<slug:slug>/", views.article_detail),
    path("articles/<slug:slug>/view/", views.article_view),
    path("admin/overview/", views.overview),
    path("admin/state/", views.set_state),
    path("admin/approvals/<int:pk>/decide/", views.decide),
    path("admin/run/", views.run_now),
]
