import hmac
from django.conf import settings
from rest_framework.permissions import BasePermission


class AdminKey(BasePermission):
    def has_permission(self, request, view):
        key = settings.ADMIN_API_KEY
        return bool(key) and hmac.compare_digest(request.headers.get("X-Admin-Key", ""), key)
