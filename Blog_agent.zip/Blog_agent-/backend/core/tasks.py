from celery import shared_task
from . import orchestrator


@shared_task
def tick():
    return orchestrator.tick()


@shared_task
def freshness_check():
    return orchestrator.freshness_check()


@shared_task
def analytics():
    return orchestrator.analytics()
