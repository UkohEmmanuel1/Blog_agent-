from django.contrib import admin
from . import models

for m in (models.NewsSource, models.Story, models.StoryClaim, models.Article, models.ArticleRevision,
          models.CodeSnippet, models.Approval, models.MediaAsset, models.SocialAccount,
          models.SocialPost, models.AgentRun, models.AuditLog, models.ArticleMetric, models.SystemState):
    admin.site.register(m)
