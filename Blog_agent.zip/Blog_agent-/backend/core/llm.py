import json
import re
from django.conf import settings
from openai import OpenAI


class LLMNotConfigured(Exception):
    pass


def chat(system: str, user: str, json_mode: bool = False, temperature: float = 0.4) -> str:
    if not settings.LLM_API_KEY:
        raise LLMNotConfigured("LLM_API_KEY is not set")
    client = OpenAI(api_key=settings.LLM_API_KEY, base_url=settings.LLM_BASE_URL)
    kwargs = {"response_format": {"type": "json_object"}} if json_mode else {}
    r = client.chat.completions.create(
        model=settings.LLM_MODEL, temperature=temperature, **kwargs,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
    )
    return r.choices[0].message.content or ""


def chat_json(system: str, user: str) -> dict:
    raw = chat(system + "\nRespond with a single JSON object and nothing else.", user, json_mode=True)
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    return json.loads(raw)
